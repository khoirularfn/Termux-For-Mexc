# ABSOLUTE_SPOT_DOMINATOR_FINAL_FULL_AGI_PLUS_PLUS
# AGI++++ Level MEXC Spot Live Autopilot Bot

import time
import schedule
from config import API_KEY, API_SECRET, TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
from utils.signal_validator import validate_signals
from utils.entry_engine import execute_entry
from utils.order_manager import manage_orders
from utils.telegram_notifier import notify
from utils.restart_handler import auto_restart
from utils.json_logger import log_trade

def job():
    if validate_signals():
        execute_entry()
        manage_orders()
        notify("Trade executed successfully.")
        log_trade()

schedule.every(10).seconds.do(job)

while True:
    schedule.run_pending()
    time.sleep(1)
